package dev.hotbartotem;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class HotbarTotemConfigScreen extends Screen {
    private final Screen parent;
    private ButtonWidget enabledButton;
    private ButtonWidget slotButton;

    public HotbarTotemConfigScreen(Screen parent) {
        super(Text.literal("Hotbar Totem Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int center = this.width / 2;
        enabledButton = ButtonWidget.builder(enabledText(), button -> {
            HotbarTotemClient.CONFIG.enabled = !HotbarTotemClient.CONFIG.enabled;
            HotbarTotemClient.CONFIG.save();
            button.setMessage(enabledText());
        }).dimensions(center - 100, this.height / 2 - 40, 200, 20).build();
        addDrawableChild(enabledButton);

        slotButton = ButtonWidget.builder(slotText(), button -> {
            HotbarTotemClient.CONFIG.hotbarSlot++;
            if (HotbarTotemClient.CONFIG.hotbarSlot > 9) HotbarTotemClient.CONFIG.hotbarSlot = 0;
            HotbarTotemClient.CONFIG.save();
            button.setMessage(slotText());
        }).dimensions(center - 100, this.height / 2 - 10, 200, 20).build();
        addDrawableChild(slotButton);

        addDrawableChild(ButtonWidget.builder(Text.literal("Random delay: 100–250 ms"), button -> {})
                .dimensions(center - 100, this.height / 2 + 20, 200, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> close())
                .dimensions(center - 100, this.height / 2 + 55, 200, 20).build());
    }

    private Text enabledText() {
        return Text.literal("Mod: " + (HotbarTotemClient.CONFIG.enabled ? "ON" : "OFF"));
    }

    private Text slotText() {
        int slot = HotbarTotemClient.CONFIG.hotbarSlot;
        return Text.literal("Totem slot: " + (slot == 0 ? "Auto (all 9 slots)" : slot));
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }
}
