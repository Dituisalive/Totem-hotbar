package dev.hotbartotem;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class HotbarTotemConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("hotbar-totem.json");

    public boolean enabled = true;
    // 0 means Auto (search all nine slots); 1-9 means only that hotbar slot.
    public int hotbarSlot = 0;
    public int minDelayMs = 100;
    public int maxDelayMs = 250;

    public static HotbarTotemConfig load() {
        try {
            if (Files.exists(PATH)) {
                HotbarTotemConfig loaded = GSON.fromJson(Files.readString(PATH), HotbarTotemConfig.class);
                if (loaded != null) {
                    loaded.hotbarSlot = Math.max(0, Math.min(9, loaded.hotbarSlot));
                    loaded.minDelayMs = 100;
                    loaded.maxDelayMs = 250;
                    return loaded;
                }
            }
        } catch (Exception ignored) {
        }
        HotbarTotemConfig config = new HotbarTotemConfig();
        config.save();
        return config;
    }

    public void save() {
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(this));
        } catch (IOException ignored) {
        }
    }
}
