package dev.hotbartotem;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

import java.util.concurrent.ThreadLocalRandom;

public final class HotbarTotemClient implements ClientModInitializer {
    public static HotbarTotemConfig CONFIG;
    private static long swapAtNanos = -1L;
    private static int pendingSlot = -1;

    @Override
    public void onInitializeClient() {
        CONFIG = HotbarTotemConfig.load();
        ClientTickEvents.END_CLIENT_TICK.register(HotbarTotemClient::onEndTick);
    }

    private static void onEndTick(MinecraftClient client) {
        if (client.player == null || client.interactionManager == null) {
            cancelPending();
            return;
        }

        if (!CONFIG.enabled || client.currentScreen != null
                || client.player.currentScreenHandler != client.player.playerScreenHandler) {
            cancelPending();
            return;
        }

        if (!client.player.getOffHandStack().isEmpty()) {
            cancelPending();
            return;
        }

        if (pendingSlot < 0) {
            pendingSlot = findTotemSlot(client);
            if (pendingSlot < 0) return;

            int delayMs = ThreadLocalRandom.current().nextInt(100, 251);
            swapAtNanos = System.nanoTime() + delayMs * 1_000_000L;
            return;
        }

        // Cancel if the chosen slot no longer contains a totem.
        if (!client.player.getInventory().getStack(pendingSlot).isOf(Items.TOTEM_OF_UNDYING)) {
            cancelPending();
            return;
        }

        if (System.nanoTime() < swapAtNanos) return;

        // PlayerScreenHandler slot 45 is offhand; SWAP button 0-8 selects hotbar slot.
        client.interactionManager.clickSlot(
                client.player.playerScreenHandler.syncId,
                45,
                pendingSlot,
                SlotActionType.SWAP,
                client.player
        );
        cancelPending();
    }

    private static int findTotemSlot(MinecraftClient client) {
        if (CONFIG.hotbarSlot >= 1 && CONFIG.hotbarSlot <= 9) {
            int selected = CONFIG.hotbarSlot - 1;
            return client.player.getInventory().getStack(selected).isOf(Items.TOTEM_OF_UNDYING)
                    ? selected : -1;
        }
        for (int i = 0; i < 9; i++) {
            if (client.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                return i;
            }
        }
        return -1;
    }

    private static void cancelPending() {
        pendingSlot = -1;
        swapAtNanos = -1L;
    }
}
