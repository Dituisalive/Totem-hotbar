# Hotbar Totem 1.1.0 — Fabric 1.21.11

Client-side Fabric mod source project.

## Features
- Automatically swaps a Totem of Undying from the hotbar to the offhand when the offhand is empty.
- Random delay for each swap: 100–250 ms.
- Enable/disable toggle and hotbar slot selector in the Mod Menu configuration screen.
- Slot selector cycles through Auto and slots 1–9.
- Auto scans the hotbar from left to right.
- Does not act while a GUI is open or when the offhand is occupied.
- Saves settings to `config/hotbar-totem.json`.

## Build
This ZIP contains source code, not a ready-to-install JAR. Build with JDK 21 and Gradle:
```sh
gradle build
```
The JAR will be in `build/libs/`.

## Install
Use Minecraft Java 1.21.11, Fabric Loader, and Fabric API. Install Mod Menu too if you want the configuration button to appear in Mod Menu. The mod's `modmenu` integration is optional; without Mod Menu, the swap behavior can still load, but the GUI settings page will not be accessible through Mod Menu.

## Timing note
The mod chooses a random delay from 100 to 250 ms. Because Minecraft client actions are processed on ticks, the actual click occurs on the next client tick after the chosen delay, so observed timing can be slightly longer.
